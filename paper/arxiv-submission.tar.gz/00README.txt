arXiv source submission.
Main file: lsp-token-efficiency-paper.tex  (self-contained; standard packages only)
Figures:   figs/fig1..fig6 (PDF)
Compile:   pdflatex x2  (or latexmk -pdf). No bibliography file (citations are inline).
Suggested categories: cs.SE (primary), cs.AI (cross-list).
